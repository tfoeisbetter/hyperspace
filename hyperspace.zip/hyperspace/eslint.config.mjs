export default [
	{
		ignores: ["**/node_modules"],
	},
	{
		languageOptions: {
			ecmaVersion: "latest",
			sourceType: "module",
		},
	},
];
